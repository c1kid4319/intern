import React from 'react';
import { Sidebar } from './Sidebar';
import { SearchBar } from '../Header/SearchBar';
import { NotificationsMenu } from '../Header/NotificationsMenu';
import { UserProfile } from '../Header/UserProfile';

interface MainLayoutProps {
  children: React.ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 fixed top-0 left-0 right-0 z-10">
        <div className="px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <h1 className="text-xl font-bold text-gray-900">Bus Management</h1>
            </div>
            <div className="flex items-center space-x-4">
              <SearchBar />
              <NotificationsMenu />
              <UserProfile />
            </div>
          </div>
        </div>
      </header>

      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <main className="pt-16 pl-64">
        <div className="p-8">
          {children}
        </div>
      </main>
    </div>
  );
}