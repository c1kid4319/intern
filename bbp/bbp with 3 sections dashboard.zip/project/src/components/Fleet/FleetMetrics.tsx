import React from 'react';
import { Bus, AlertTriangle, CheckCircle, Wrench } from 'lucide-react';

const metrics = [
  {
    title: 'Total Buses',
    value: '45',
    icon: <Bus className="h-6 w-6 text-blue-600" />,
    bgColor: 'bg-blue-50',
  },
  {
    title: 'Active Buses',
    value: '38',
    percentage: '84%',
    icon: <CheckCircle className="h-6 w-6 text-green-600" />,
    bgColor: 'bg-green-50',
  },
  {
    title: 'Inactive Buses',
    value: '7',
    percentage: '16%',
    icon: <AlertTriangle className="h-6 w-6 text-red-600" />,
    bgColor: 'bg-red-50',
  },
  {
    title: 'Pending Maintenance',
    value: '4',
    icon: <Wrench className="h-6 w-6 text-yellow-600" />,
    bgColor: 'bg-yellow-50',
  },
];

export function FleetMetrics() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {metrics.map((metric) => (
        <div key={metric.title} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex justify-between items-start mb-4">
            <div className={`h-12 w-12 rounded-lg ${metric.bgColor} flex items-center justify-center`}>
              {metric.icon}
            </div>
          </div>
          <h3 className="text-gray-500 text-sm mb-1">{metric.title}</h3>
          <div className="flex items-baseline space-x-4">
            <h2 className="text-2xl font-bold">{metric.value}</h2>
            {metric.percentage && (
              <span className="text-sm text-gray-500">{metric.percentage}</span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}