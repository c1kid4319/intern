import React, { useState } from 'react';
import { MainLayout } from '../components/Layout/MainLayout';
import { FleetMetrics } from '../components/Fleet/FleetMetrics';
import { BusTable } from '../components/Fleet/BusTable';
import { BusDetailsModal } from '../components/Fleet/BusDetailsModal';
import { FilterBar } from '../components/Fleet/FilterBar';
import { Plus } from 'lucide-react';

export function FleetManagement() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedBus, setSelectedBus] = useState<string | null>(null);

  return (
    <MainLayout>
      <div className="mb-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Fleet Management</h1>
        <button
          onClick={() => setIsModalOpen(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 hover:bg-blue-700"
        >
          <Plus className="h-5 w-5" />
          <span>Add New Bus</span>
        </button>
      </div>

      <FleetMetrics />
      <FilterBar />
      <BusTable onBusSelect={setSelectedBus} />

      {selectedBus && (
        <BusDetailsModal
          busId={selectedBus}
          isOpen={true}
          onClose={() => setSelectedBus(null)}
        />
      )}
    </MainLayout>
  );
}