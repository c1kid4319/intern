import React from 'react';
import { MainLayout } from '../components/Layout/MainLayout';
import { MetricCard } from '../components/Dashboard/MetricCard';
import { RevenueChart } from '../components/Dashboard/Charts/RevenueChart';
import { ActivityLog } from '../components/Dashboard/ActivityLog';
import { Bus, Users, Route as RouteIcon, IndianRupee } from 'lucide-react';

export function Dashboard() {
  return (
    <MainLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard Overview</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard
          title="Total Revenue"
          value="₹45,000"
          change={12}
          icon={<IndianRupee className="h-6 w-6 text-blue-600" />}
        />
        <MetricCard
          title="Active Buses"
          value="38"
          change={5}
          icon={<Bus className="h-6 w-6 text-blue-600" />}
        />
        <MetricCard
          title="Total Conductors"
          value="42"
          change={-2}
          icon={<Users className="h-6 w-6 text-blue-600" />}
        />
        <MetricCard
          title="Active Routes"
          value="15"
          change={8}
          icon={<RouteIcon className="h-6 w-6 text-blue-600" />}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <RevenueChart />
        </div>
        <div>
          <ActivityLog />
        </div>
      </div>
    </MainLayout>
  );
}