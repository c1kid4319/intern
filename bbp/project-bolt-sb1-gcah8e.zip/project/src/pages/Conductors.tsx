import React, { useState } from 'react';
import { MainLayout } from '../components/Layout/MainLayout';
import { ConductorMetrics } from '../components/Conductors/ConductorMetrics';
import { ConductorTable } from '../components/Conductors/ConductorTable';
import { ConductorProfile } from '../components/Conductors/ConductorProfile';
import { ConductorFilters } from '../components/Conductors/ConductorFilters';
import { Plus } from 'lucide-react';

export function Conductors() {
  const [selectedEmployee, setSelectedEmployee] = useState<string | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  return (
    <MainLayout>
      <div className="mb-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Employee Management</h1>
        <button
          onClick={() => setIsProfileOpen(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 hover:bg-blue-700"
        >
          <Plus className="h-5 w-5" />
          <span>Add New Employee</span>
        </button>
      </div>

      <ConductorMetrics />
      <ConductorFilters />
      <ConductorTable onEmployeeSelect={setSelectedEmployee} />

      {selectedEmployee && (
        <ConductorProfile
          employeeId={selectedEmployee}
          isOpen={true}
          onClose={() => setSelectedEmployee(null)}
        />
      )}
    </MainLayout>
  );
}