import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Bus,
  Users,
  Route as RouteIcon,
  BarChart2,
  FileText,
  Settings,
  Calendar,
  Wrench
} from 'lucide-react';

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  path: string;
  isActive?: boolean;
  hasNotification?: boolean;
}

function NavItem({ icon, label, path, isActive, hasNotification }: NavItemProps) {
  const navigate = useNavigate();
  
  return (
    <button
      onClick={() => navigate(path)}
      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
        isActive ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50'
      }`}
    >
      {icon}
      <span className="font-medium">{label}</span>
      {hasNotification && (
        <span className="ml-auto h-2 w-2 rounded-full bg-blue-600"></span>
      )}
    </button>
  );
}

export function Sidebar() {
  const location = useLocation();

  return (
    <div className="fixed left-0 top-16 h-[calc(100vh-4rem)] w-64 bg-white border-r border-gray-200 p-4">
      <div className="space-y-1">
        <NavItem
          icon={<LayoutDashboard className="h-5 w-5" />}
          label="Dashboard"
          path="/"
          isActive={location.pathname === '/'}
        />
        <NavItem
          icon={<Bus className="h-5 w-5" />}
          label="Fleet Management"
          path="/fleet"
          isActive={location.pathname === '/fleet'}
          hasNotification={true}
        />
        <NavItem
          icon={<Users className="h-5 w-5" />}
          label="Conductors"
          path="/conductors"
          isActive={location.pathname === '/conductors'}
        />
        <NavItem
          icon={<RouteIcon className="h-5 w-5" />}
          label="Routes"
          path="/routes"
          isActive={location.pathname === '/routes'}
        />
        <NavItem
          icon={<BarChart2 className="h-5 w-5" />}
          label="Analytics"
          path="/analytics"
          isActive={location.pathname === '/analytics'}
        />
        <NavItem
          icon={<FileText className="h-5 w-5" />}
          label="Documents"
          path="/documents"
          isActive={location.pathname === '/documents'}
        />
      </div>

      <div className="mt-8 space-y-1">
        <div className="px-4 py-2 text-xs font-semibold text-gray-400 uppercase">
          Additional Features
        </div>
        <NavItem
          icon={<Calendar className="h-5 w-5" />}
          label="Schedule"
          path="/schedule"
          isActive={location.pathname === '/schedule'}
        />
        <NavItem
          icon={<Wrench className="h-5 w-5" />}
          label="Maintenance"
          path="/maintenance"
          isActive={location.pathname === '/maintenance'}
        />
        <NavItem
          icon={<Settings className="h-5 w-5" />}
          label="Settings"
          path="/settings"
          isActive={location.pathname === '/settings'}
        />
      </div>
    </div>
  );
}