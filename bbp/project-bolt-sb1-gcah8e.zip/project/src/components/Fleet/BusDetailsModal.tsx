import React from 'react';
import { X, FileText, MapPin, Calendar, AlertTriangle } from 'lucide-react';

interface BusDetailsModalProps {
  busId: string;
  isOpen: boolean;
  onClose: () => void;
}

export function BusDetailsModal({ busId, isOpen, onClose }: BusDetailsModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-3xl mx-4">
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-xl font-semibold">Bus Details</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold mb-4">General Information</h3>
              <div className="space-y-3">
                <div>
                  <label className="text-sm text-gray-500">Registration Number</label>
                  <p className="font-medium">KA-01-HQ-1234</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500">Model</label>
                  <p className="font-medium">Ashok Leyland Viking</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500">Seating Capacity</label>
                  <p className="font-medium">45 seats</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Operational Data</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <MapPin className="h-5 w-5 text-gray-400" />
                  <div>
                    <label className="text-sm text-gray-500">Current Route</label>
                    <p className="font-medium">Route A1: City Center - Airport</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="h-5 w-5 text-gray-400" />
                  <div>
                    <label className="text-sm text-gray-500">Next Maintenance</label>
                    <p className="font-medium">April 15, 2024</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-500" />
                  <div>
                    <label className="text-sm text-gray-500">Alerts</label>
                    <p className="font-medium text-yellow-600">Maintenance due in 15 days</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6">
            <h3 className="font-semibold mb-4">Documents</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {['RC Book', 'Insurance', 'Permit'].map((doc) => (
                <div key={doc} className="border rounded-lg p-4 flex items-center space-x-3">
                  <FileText className="h-6 w-6 text-blue-500" />
                  <div>
                    <p className="font-medium">{doc}</p>
                    <button className="text-sm text-blue-600">View</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-3 p-6 border-t bg-gray-50 rounded-b-lg">
          <button
            onClick={onClose}
            className="px-4 py-2 border rounded-lg hover:bg-gray-50"
          >
            Close
          </button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            Edit Details
          </button>
        </div>
      </div>
    </div>
  );
}