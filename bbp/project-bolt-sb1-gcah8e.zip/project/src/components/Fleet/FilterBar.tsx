import React from 'react';
import { Filter, SortAsc } from 'lucide-react';

export function FilterBar() {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 mb-6">
      <div className="flex flex-wrap gap-4 items-center">
        <div className="flex items-center space-x-2">
          <Filter className="h-5 w-5 text-gray-400" />
          <select className="form-select rounded-lg border-gray-200">
            <option value="all">All Buses</option>
            <option value="active">Active Only</option>
            <option value="inactive">Inactive Only</option>
          </select>
        </div>

        <div className="flex items-center space-x-2">
          <SortAsc className="h-5 w-5 text-gray-400" />
          <select className="form-select rounded-lg border-gray-200">
            <option value="route">Sort by Route</option>
            <option value="status">Sort by Status</option>
            <option value="maintenance">Sort by Maintenance Date</option>
          </select>
        </div>
      </div>
    </div>
  );
}