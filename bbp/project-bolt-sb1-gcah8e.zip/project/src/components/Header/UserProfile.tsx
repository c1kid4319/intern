import React, { useState } from 'react';
import { User, LogOut, Settings } from 'lucide-react';

export function UserProfile() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-100"
      >
        <div className="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center">
          <User className="h-5 w-5 text-white" />
        </div>
        <span className="hidden md:inline text-sm font-medium">John Doe</span>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200">
          <div className="p-2">
            <button className="w-full flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-100">
              <Settings className="h-4 w-4" />
              <span>Settings</span>
            </button>
            <button className="w-full flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-100 text-red-600">
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}