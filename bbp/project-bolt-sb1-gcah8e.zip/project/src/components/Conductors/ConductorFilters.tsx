import React from 'react';
import { Filter, SortAsc } from 'lucide-react';

export function ConductorFilters() {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 mb-6">
      <div className="flex flex-wrap gap-4 items-center">
        <div className="flex items-center space-x-2">
          <Filter className="h-5 w-5 text-gray-400" />
          <select className="form-select rounded-lg border-gray-200">
            <option value="all">All Roles</option>
            <option value="conductor">Conductors</option>
            <option value="driver">Drivers</option>
            <option value="cleaner">Cleaners</option>
          </select>
        </div>

        <div className="flex items-center space-x-2">
          <SortAsc className="h-5 w-5 text-gray-400" />
          <select className="form-select rounded-lg border-gray-200">
            <option value="name">Sort by Name</option>
            <option value="role">Sort by Role</option>
            <option value="status">Sort by Status</option>
          </select>
        </div>
      </div>
    </div>
  );
}