import React from 'react';
import { Users, UserCheck, AlertTriangle, FileWarning } from 'lucide-react';

const metrics = [
  {
    title: 'Total Employees',
    value: '87',
    icon: <Users className="h-6 w-6 text-blue-600" />,
    bgColor: 'bg-blue-50',
  },
  {
    title: 'Active Employees',
    value: '82',
    percentage: '94%',
    icon: <UserCheck className="h-6 w-6 text-green-600" />,
    bgColor: 'bg-green-50',
  },
  {
    title: 'On Leave',
    value: '5',
    percentage: '6%',
    icon: <AlertTriangle className="h-6 w-6 text-yellow-600" />,
    bgColor: 'bg-yellow-50',
  },
  {
    title: 'Pending Verifications',
    value: '3',
    icon: <FileWarning className="h-6 w-6 text-red-600" />,
    bgColor: 'bg-red-50',
  },
];

export function ConductorMetrics() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {metrics.map((metric) => (
        <div key={metric.title} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex justify-between items-start mb-4">
            <div className={`h-12 w-12 rounded-lg ${metric.bgColor} flex items-center justify-center`}>
              {metric.icon}
            </div>
          </div>
          <h3 className="text-gray-500 text-sm mb-1">{metric.title}</h3>
          <div className="flex items-baseline space-x-4">
            <h2 className="text-2xl font-bold">{metric.value}</h2>
            {metric.percentage && (
              <span className="text-sm text-gray-500">{metric.percentage}</span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}