import React from 'react';
import { X, Phone, Mail, MapPin, FileText, Calendar, AlertTriangle } from 'lucide-react';

interface ConductorProfileProps {
  employeeId: string;
  isOpen: boolean;
  onClose: () => void;
}

export function ConductorProfile({ employeeId, isOpen, onClose }: ConductorProfileProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-3xl mx-4">
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-xl font-semibold">Employee Profile</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6">
          <div className="flex items-center mb-6">
            <div className="h-20 w-20 rounded-full bg-gray-200 flex items-center justify-center text-xl font-semibold">
              JD
            </div>
            <div className="ml-4">
              <h3 className="text-xl font-semibold">John Doe</h3>
              <p className="text-gray-500">Conductor - ID: {employeeId}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold mb-4">Personal Information</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Phone className="h-5 w-5 text-gray-400" />
                  <div>
                    <label className="text-sm text-gray-500">Phone</label>
                    <p className="font-medium">+91 9876543210</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Mail className="h-5 w-5 text-gray-400" />
                  <div>
                    <label className="text-sm text-gray-500">Email</label>
                    <p className="font-medium">john.doe@example.com</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="h-5 w-5 text-gray-400" />
                  <div>
                    <label className="text-sm text-gray-500">Address</label>
                    <p className="font-medium">123 Main St, Bangalore</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Work Information</h3>
              <div className="space-y-3">
                <div>
                  <label className="text-sm text-gray-500">Assigned Bus</label>
                  <p className="font-medium">KA-01-HQ-1234</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500">Route</label>
                  <p className="font-medium">Route A1: City Center - Airport</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500">Shift Timing</label>
                  <p className="font-medium">Morning Shift (6:00 AM - 2:00 PM)</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6">
            <h3 className="font-semibold mb-4">Documents</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {['ID Proof', 'Address Proof', 'License'].map((doc) => (
                <div key={doc} className="border rounded-lg p-4 flex items-center space-x-3">
                  <FileText className="h-6 w-6 text-blue-500" />
                  <div>
                    <p className="font-medium">{doc}</p>
                    <button className="text-sm text-blue-600">View</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-3 p-6 border-t bg-gray-50 rounded-b-lg">
          <button
            onClick={onClose}
            className="px-4 py-2 border rounded-lg hover:bg-gray-50"
          >
            Close
          </button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            Edit Profile
          </button>
        </div>
      </div>
    </div>
  );
}