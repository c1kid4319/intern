import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string;
  change: number;
  icon: React.ReactNode;
}

export function MetricCard({ title, value, change, icon }: MetricCardProps) {
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <div className="flex justify-between items-start mb-4">
        <div className="h-12 w-12 rounded-lg bg-blue-50 flex items-center justify-center">
          {icon}
        </div>
      </div>
      <h3 className="text-gray-500 text-sm mb-1">{title}</h3>
      <div className="flex items-baseline space-x-4">
        <h2 className="text-2xl font-bold">{value}</h2>
        <span className={`flex items-center text-sm ${change >= 0 ? 'text-green-500' : 'text-red-500'}`}>
          {change >= 0 ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
          {Math.abs(change)}%
        </span>
      </div>
    </div>
  );
}