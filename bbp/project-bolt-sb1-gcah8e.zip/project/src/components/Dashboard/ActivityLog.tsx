import React from 'react';
import { Clock, AlertCircle } from 'lucide-react';

const activities = [
  {
    id: 1,
    type: 'trip',
    title: 'Trip Completed',
    description: 'Bus #123 completed route A1 with revenue ₹5,000',
    time: '10 minutes ago'
  },
  {
    id: 2,
    type: 'alert',
    title: 'Insurance Renewal',
    description: 'Bus #456 insurance expires in 7 days',
    time: '1 hour ago'
  }
];

export function ActivityLog() {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
      <div className="space-y-4">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg">
            <div className={`p-2 rounded-full ${
              activity.type === 'trip' ? 'bg-green-100' : 'bg-yellow-100'
            }`}>
              {activity.type === 'trip' ? 
                <Clock className="h-5 w-5 text-green-600" /> : 
                <AlertCircle className="h-5 w-5 text-yellow-600" />
              }
            </div>
            <div className="flex-1">
              <h3 className="font-medium">{activity.title}</h3>
              <p className="text-sm text-gray-600">{activity.description}</p>
              <span className="text-xs text-gray-400">{activity.time}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}