import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { date: '1 Mar', revenue: 4000 },
  { date: '2 Mar', revenue: 3000 },
  { date: '3 Mar', revenue: 5000 },
  { date: '4 Mar', revenue: 2780 },
  { date: '5 Mar', revenue: 1890 },
  { date: '6 Mar', revenue: 2390 },
  { date: '7 Mar', revenue: 3490 }
];

export function RevenueChart() {
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <h2 className="text-xl font-semibold mb-4">Revenue Trend</h2>
      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="revenue" stroke="#3B82F6" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}